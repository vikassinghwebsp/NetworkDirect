<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Class Admin_model extends CI_Model {

    public function getUser($arrdata) {
        return $this->db->select('*')
                        ->from('tbl_users')
                        ->where('email_id', $arrdata['email_id'])
                        ->where('password', md5($arrdata['password']))
                        ->get()->row();
    }

    public function getUserDetail($id) {
        return $this->db->select('*')
                        ->from('tbl_admin')
                        ->where('id', $id)
                        ->get()->row();
    }

}
