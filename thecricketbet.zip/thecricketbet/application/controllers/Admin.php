<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
//        $this->load->library('pagination');
//        $this->load->helper('url');
//        $this->load->library('email');
//        $this->load->library('Custom_session');
    }

    public function dashboard() {

        $this->custom_session->checkLogedIn();
        $arrContent = array();

        $arrContent['userData'] = $this->custom_session->custom_userdata();

        $this->layout->view('dashboard', $arrContent);
    }

    public function login() {
        //echo 'hiiiiiiiii';exit;
        $this->custom_session->checkLogin();

        if (!empty($this->input->post())) {
            $post = $this->input->post();
            $arrData = array(
                'email_id' => $post['email_id'],
                'password' => $post['password'],
            );

            $user = $this->Admin_model->getUser($arrData);
            // var_dump($user);exit;
            if (count($user) > 0) {
                $this->session->set_userdata('user', $user);
                redirect(base_url('/dashboard'));
            } else {
                $this->session->set_flashdata('error', 'Invalid username or password');
            }
            redirect(base_url('backend'));
        }
        $msg = $this->session->flashdata('error');
        $arrDataContent['msg'] = $msg;
        $this->load->view('login', $arrDataContent);
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url('backend'));
    }

}
