$(document).ready(function () {

  $('#logout').popup({
    transition: 'ease-in-out 0.3s',
    vertical: 'top'
  });

});